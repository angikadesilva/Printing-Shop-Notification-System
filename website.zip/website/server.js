const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post('/send-email', (req, res) => {
  const { name, email, subject, message } = req.body;

  const transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth: {
      user: 'sadeeshaaa25@email.com',
      pass: '1234'
    }
  });

  const mailOptions = {
    from: email,
    to: 'sadeeshaaa25@email.com', // Change this to your business email
    subject: subject,
    text: `Name: ${name}\nEmail: ${email}\nMessage: ${message}`
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log(error);
      res.status(500).send('Error sending email');
    } else {
      console.log('Email sent: ' + info.response);
      res.status(200).send('Email sent successfully');
    }
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);

  const contactform = document.querySelector('.contact-form');
const container = document.querySelector('.container');

contactform.addEventListener('submit', async (event) => {
  event.preventDefault();
  
  const formData = new FormData(contactform);
  const data = Object.fromEntries(formData.entries());

  try {
    const response = await fetch('/send-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    });

    if (response.ok) {
      container.innerHTML = '<p>Thanks for your message. <br /> I\'ll respond to you shortly</p>';
    } else {
      throw new Error('Error sending email');
    }
  } catch (error) {
    console.error(error);
    container.innerHTML = '<p>Sorry, there was an error. Please try again later.</p>';
  }


});
