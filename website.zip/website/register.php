<?php
session_start(); // Start the session


$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "shop_dp"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $name = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Password length validation
    if (strlen($password) < 8) {
        $_SESSION['message'] = "Password should be at least 8 characters long.";
        header("Location: ".$_SERVER['PHP_SELF']);
        exit;
    }

    
    $sql = "INSERT INTO user_form (name, email, password) VALUES ('$name', '$email', '$password')";

    if ($conn->query($sql) === TRUE) {
        $_SESSION['message'] = "Created successfully!";
        header("Location: cart.php");
        exit;
        
        // Alter the table to set id column to auto-increment after successful insertion
        $sql_alter = "ALTER TABLE user_form MODIFY COLUMN id INT AUTO_INCREMENT";
        if ($conn->query($sql_alter) === TRUE) {
            $_SESSION['message'] .= "";
        } else {
            $_SESSION['message'] .= "<br>Error altering table: " . $conn->error;
        }
    } else {
        $_SESSION['message'] = "Error: " . $sql . "<br>" . $conn->error;
    }
    
    
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>register</title>

   
   <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');


    body {
    font-family: "Arial", sans-serif;
    margin: 0;
    padding: 0;
    background-color: #fff; 
}

.form-container {
    width: 100%;
    max-width: 450px;
    margin: 100px auto;
    padding: 20px;
    background-color: #fff;
    border: 3px solid #ffb411; 
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
}

.form-container h3 {
    text-align: center;
    margin-bottom: 20px;
    font-size: 30px;
}

.input-box {
    position: relative;
    margin-bottom: 20px;
}

.input-box input {
    width: 95%;
    padding: 10px;
    border: 1px solid #999; 
    border-radius: 5px;
    outline: none;
}

.input-box i {
    position: absolute;
    top: 50%;
    right: 10px;
    transform: translateY(-50%);
}

.remember-forgot {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
}

.remember-forgot label {
    font-size: 14px;
}

.btn {
    width: 100%;
    padding: 10px;
    border: none;
    border-radius: 5px;
    background-color: #ffb411;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
    outline: none;
}

.btn:hover {
    background-color: #d45b15; /* changed hover color to darker coral */
}

.register-link {
    text-align: center;
}

.register-link a {
    color: #ffb411; 
    text-decoration: none;
}

.message {
    background-color: #f8d7da;
    color: #ffb411;
    padding: 10px;
    margin-bottom: 20px;
    border-radius: 4px;
}
   </style>

</head>
<body>
   
<div class="form-container">

   <form action="" method="post">
      <h3>Register</h3>
     
      <?php if(isset($_SESSION['message'])): ?>
      <div class="message"><?php echo $_SESSION['message']; ?></div>
      <?php unset($_SESSION['message']); // Unset the session message after displaying ?>
      <?php endif; ?>

   
      <div class="input-box">
      <input type="text" name="username" required placeholder="Enter username" class="box">
      <i class='bx bxs-user'></i>
      </div>
      <div class="input-box">
      <input type="email" name="email" required placeholder="Enter email" class="box">
      <i class='bx bxs-email'></i>
      </div>
      <div class="input-box">
      <input type="password" name="password" required placeholder="Enter password" class="box">
      <i class='bx bxs-pass'></i>
      </div>
      <div class="input-box">
      <input type="password" name="cpassword" required placeholder="Confirm password" class="box">
      <i class='bx bxs-cpass'></i>
      </div>
      <input type="submit" name="submit" class="btn" value="Register">
      <div class="login-link">
      <p>already have an account? <a href="login.php">login now</a></p>
      </div>
   </form>

</div>

</body>
</html>
