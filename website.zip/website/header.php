<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Header with Cart Count</title>

   <style>
   
      .header {
         background-color: #ffb411;
         position: sticky;
         top: 0;
         left: 0;
         z-index: 800;
      }

      .header .flex {
         display: flex;
         align-items: center; 
         padding: 1rem 1rem;
         max-width: 1400px;
         margin: 0 auto;
      }

      .header .flex .navbar a {
         font-size: 18px;
         color: white;
         text-decoration: none; 
         font-family: Arial, Helvetica, sans-serif;
         margin-right: 20px; /* Adjust this value to increase the gap */
      }

      .header .flex .navbar a:last-child {
         margin-right: 0; /* Remove margin from the last item */
      }

      .header .flex .navbar a:hover {
         text-decoration: underline; 
      }

      .header .flex .cart {
         font-size: 18px;
         color: white;
         margin-left: 1rem; 
         text-decoration: none; 
         font-family: Arial, Helvetica, sans-serif;
      }

      .header .flex .cart:hover {
         text-decoration: underline; 
      }
   </style>
</head>
<body>

   <header class="header">
      <div class="flex">
         <nav class="navbar">
            <a href="test.html">Home</a>
            <a href="cart.php">View products</a>
         </nav>

         <?php
         $select_rows = mysqli_query($conn, "SELECT * FROM `cart`") or die('query failed');
         $row_count = mysqli_num_rows($select_rows);
         ?>

         <a href="mycart.php" class="cart">My cart</a>
      </div>
   </header>

</body>
</html>
