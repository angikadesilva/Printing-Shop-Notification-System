<?php
@include 'config.php';

if(isset($_POST['update_update_btn'])){
   $update_value = $_POST['update_quantity'];
   $update_id = $_POST['update_quantity_id'];
   $update_email = $_POST['update_email']; // new email field
   $update_quantity_query = mysqli_query($conn, "UPDATE `cart` SET quantity = '$update_value', email = '$update_email' WHERE id = '$update_id'");
   if($update_quantity_query){
      header('location:mycart.php');
      exit(); 
   };
}

if(isset($_GET['remove'])){
   $remove_id = $_GET['remove'];
   mysqli_query($conn, "DELETE FROM `cart` WHERE id = '$remove_id'");
   header('location:mycart.php');
   exit(); 
}

if(isset($_GET['delete_all'])){
   mysqli_query($conn, "DELETE FROM `cart`");
   header('location:mycart.php');
   exit(); 
}

if(isset($_GET['notify'])) {
    $select_cart = mysqli_query($conn, "SELECT * FROM `cart`");
    if(mysqli_num_rows($select_cart) > 0) {
        while($fetch_cart = mysqli_fetch_assoc($select_cart)) {
            $product_name = $fetch_cart['name'];
            $product_price = $fetch_cart['price'];
            $product_image = $fetch_cart['image'];
            $customer_email = $fetch_cart['email']; // fetching email
            
            mysqli_query($conn, "INSERT INTO `notification` (name, price, image, email) VALUES ('$product_name', '$product_price', '$product_image', '$customer_email')");
        }
        mysqli_query($conn, "DELETE FROM `cart`"); // Clear the cart table
        header('Location: mycart.php?notification=success');
        exit();
    }
}

// Check if notification message is set
$notification_message = '';
if(isset($_GET['notification']) && $_GET['notification'] == 'success') {
    $notification_message = 'Products notified successfully!';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Shopping Cart</title>
   <style>
 body {
         font-family: Arial, sans-serif;
         margin: 0;
         padding: 0;
         background-color: #ddd;
      }
.header {
   background-color: #ffb411;
   position: sticky;
   top: 0;
   left: 0;
   z-index: 800;
}

.header .flex {
   display: flex;
   align-items: center; 
   padding: 1rem 1rem;
   max-width: 1400px;
   margin: 0 auto;
}

.header .flex .navbar a {
   font-size: 18px;
   color: white;
   text-decoration: none; 
   font-family:Arial, Helvetica, sans-serif;
}

.header .flex .navbar a:hover {
   text-decoration: underline; 
}

.header .flex .cart {
   font-size: 18px;
   color: white;
   margin-left: 1rem; 
   text-decoration: none; 
   font-family:Arial, Helvetica, sans-serif;
}

.header .flex .cart:hover {
   text-decoration: underline; 
}

.shopping-cart {
   margin-top: 20px;
}
.shopping-cart h1{
    font-size: 30px;
    font-family:Arial, Helvetica, sans-serif;
    margin-left: 20px;
}

.shopping-cart table {
   width: 100%;
   border-collapse: collapse;
   background-color: #fff;
   box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.shopping-cart th,
.shopping-cart td {
   padding: 10px;
   border-bottom: 1px solid #ddd;
   text-align: left;
   font-family:Arial, Helvetica, sans-serif;
}

.shopping-cart th {
   background-color: #f8f9fa;
   font-weight: bold;
   font-family:Arial, Helvetica, sans-serif;
}

.shopping-cart tbody tr:hover {
   background-color: #f2f2f2;
}

.shopping-cart td img {
   max-width: 100px;
   height: auto;
}

.shopping-cart td:last-child {
   text-align: center;
}

.shopping-cart .table-bottom td {
   font-weight: bold;
}

.notification-btn {
   margin-top: 20px;
   text-align: center;
}

.notification-btn .btn {
   display: inline-block;
   padding: 15px 50px;
   border: none;
   border-radius: 4px;
   background-color: #ffb411;
   color: #fff;
   font-size: 18px;
   cursor: pointer;
   text-align: center;
   font-family:Arial, Helvetica, sans-serif;
}

.notification-btn .btn.disabled {
   background-color: #ccc;
   cursor: not-allowed;
}

.notification-btn .btn:hover {
   text-decoration: underline;
}
    </style>
</head>
<body>

<header class="header">
   <div class="flex">
      <nav class="navbar">
         <a href="cart.php">View products</a>
      </nav>

      <?php
      $select_rows = mysqli_query($conn, "SELECT * FROM `cart`") or die('query failed');
      $row_count = mysqli_num_rows($select_rows);
      ?>
      <a href="mycart.php" class="cart">My cart</a>
   </div>
</header>

<div class="container">

<section class="shopping-cart">
   <h1 class="heading">Shopping Cart</h1>
   <?php if(!empty($notification_message)): ?>
   <div class="notification">
      <?php echo $notification_message; ?>
   </div>
   <?php endif; ?>
   <table>
      <thead>
         <th>Image</th>
         <th>Name</th>
         <th>Price</th>
         <th>Quantity</th>
         <th>Email</th> <!-- New Email column -->
         <th>Total Price</th>
         <th>Action</th>
      </thead>
      <tbody>
         <?php 
         $select_cart = mysqli_query($conn, "SELECT * FROM `cart`");
         $grand_total = 0;
         if(mysqli_num_rows($select_cart) > 0){
            while($fetch_cart = mysqli_fetch_assoc($select_cart)){
         ?>
         <tr>
            <td><img src="uploaded_img/<?php echo $fetch_cart['image']; ?>" height="100" alt=""></td>
            <td><?php echo $fetch_cart['name']; ?></td>
            <td>Rs.<?php echo number_format($fetch_cart['price']); ?></td>
            <td>
               <form action="" method="post">
                  <input type="hidden" name="update_quantity_id"  value="<?php echo $fetch_cart['id']; ?>" >
                  <input type="number" name="update_quantity" min="1"  value="<?php echo $fetch_cart['quantity']; ?>" >
            </td>
            <td> <!-- New email field -->
                  <input type="email" name="update_email" value="<?php echo $fetch_cart['email']; ?>" >
                  <input type="submit" value="Update" name="update_update_btn">
               </form>   
            </td>
            <td>Rs.<?php echo $sub_total = number_format($fetch_cart['price'] * $fetch_cart['quantity']); ?></td>
            <td><a href="mycart.php?remove=<?php echo $fetch_cart['id']; ?>" onclick="return confirm('Remove item from cart?')" class="delete-btn"> <i class="fas fa-trash"></i> Remove</a></td>
         </tr>
         <?php
           $grand_total += $sub_total;  
            };
         };
         ?>
         <tr class="table-bottom">
            <td><a href="products.php" class="option-btn" style="margin-top: 0;"></a></td>
            <td colspan="3">Grand Total</td>
            <td>Rs.<?php echo $grand_total; ?></td>
            <td><a href="mycart.php?delete_all" onclick="return confirm('Are you sure you want to delete all?');" class="delete-btn"> <i class="fas fa-trash"></i> Delete All </a></td>
         </tr>
      </tbody>
   </table>

   <!-- Notify button -->
   <div class="notification-btn">
      <a href="mycart.php?notify" class="btn <?= ($grand_total > 1)?'':'disabled'; ?>">Notify</a>
   </div>

</section>

</div>
   

<script src="js/script.js"></script>

</body>
</html>
