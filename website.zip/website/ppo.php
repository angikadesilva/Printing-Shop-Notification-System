<?php
@include 'config.php';

// Process order complete button click
if(isset($_POST['order_done'])) {
    // Retrieve the notification details
    $name = $_POST['name'];
    $price = $_POST['price'];
    $image = $_POST['image'];
    $email = $_POST['email'];

    // Display a success message
    echo "<script>alert('Order completed successfully!');</script>";
    
    // Delete the notification from the notification1 table
    $delete_query = "DELETE FROM `notification1` WHERE `name` = '$name' AND `price` = '$price' AND `image` = '$image' AND `email` = '$email'";
    mysqli_query($conn, $delete_query);

    // Insert the notification into the notification2 table
    $insert_query = "INSERT INTO `notification2` (`name`, `price`, `image`, `email`) VALUES ('$name', '$price', '$image', '$email')";
    mysqli_query($conn, $insert_query);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Notification 1</title>
   
   <style>
      body {
         font-family: Arial, sans-serif;
         margin: 0;
         padding: 0;
         background-color: #ddd;
      }

      .navbar {
         width: 100%;
         background-color: #ffb411;
         overflow: hidden;
         position: fixed;
         top: 0;
         z-index: 1000;
         padding: 8px 10px;
      }

      .navbar a {
         float: left;
         display: block;
         color: #f2f2f2;
         text-align: center;
         padding: 8px 10px;
         text-decoration: none;
         font-size: 18px;
         margin-left: 40px;
      }

      .navbar a:hover {
         text-decoration: underline;
      }

      .container {
         margin-top: 90px;
         text-align: center;
      }

      .notification {
         background-color: #f2f2f2;
         padding: 20px;
         margin: 20px;
         border: 1px solid #ddd;
         border-radius: 5px;
      }

      .notification h3 {
         margin-top: 0;
         margin-bottom: 10px;
      }

      .notification p {
         margin-bottom: 10px;
      }

      .notification img {
         max-width: 100px; /* Adjust the maximum width of the image */
         height: auto;
         margin-bottom: 10px;
      }

      .order-done-btn {
         background-color:#f2f2f2 ; /* Coral color for the button */
         color: white;
         padding: 10px 20px;
         border: none;
         border-radius: 5px;
         cursor: pointer;
         margin-top: 10px;
      }

      .order-done-btn:hover {
         background-color: coral; /* Darker coral color on hover */
      }

   </style>
</head>
<body>
   <div class="navbar">
      <a href="employee.html">Employee Page</a>
   </div>

   <div class="container">
      <h1>Notification 1</h1>
      <?php
      
      $select_notification = mysqli_query($conn, "SELECT * FROM `notification1`");

      if(mysqli_num_rows($select_notification) > 0) {
         while($notification = mysqli_fetch_assoc($select_notification)) {
            echo '<div class="notification">';
            echo '<h3>' . $notification['name'] . '</h3>';
            echo '<p>Price: Rs.' . $notification['price'] . '</p>';
            echo '<p>Email: ' . $notification['email'] . '</p>'; 
            echo '<img src="uploaded_img/' . $notification['image'] . '" alt="Product Image">';
            // Add Order Done form
            echo '<form method="post">';
            echo '<input type="hidden" name="name" value="' . $notification['name'] . '">';
            echo '<input type="hidden" name="price" value="' . $notification['price'] . '">';
            echo '<input type="hidden" name="image" value="' . $notification['image'] . '">';
            echo '<input type="hidden" name="email" value="' . $notification['email'] . '">'; // Include email in the form
            echo '<input type="submit" class="order-done-btn" name="order_done" value="Order Complete">';
            echo '</form>';
            echo '</div>';
         }
      } else {
         echo '<p>No notifications</p>';
      }
      ?>
   </div>
</body>
</html>
