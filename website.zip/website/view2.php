<?php
@include 'config.php';

// Fetch completed orders from notification3 table
$select_notification3 = mysqli_query($conn, "SELECT * FROM `notification3`");
$completed_orders = [];
if(mysqli_num_rows($select_notification3) > 0) {
    while($notification3 = mysqli_fetch_assoc($select_notification3)) {
        $completed_orders[] = $notification3;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Completed Orders</title>
   <style>
      body {
         font-family: Arial, sans-serif;
         background-color: #ddd;
         margin: 0;
         padding: 0;
      }

      .container {
         max-width: 1200px;
         margin: 0 auto;
         padding: 20px;
         border-color: #ffb411;
      }

      .order-container {
         background-color: #fff;
         padding: 20px;
         border-radius: 5px;
         box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
         margin-bottom: 20px;
      }

      .order-container h2 {
         font-size: 24px;
         color: #333;
         margin-bottom: 10px;
      }

      .order-item {
         border-bottom: 1px solid #ddd;
         padding: 10px 0;
         margin-bottom: 10px;
      }

      .order-item p {
         margin: 5px 0;
      }

      .empty-message {
         text-align: center;
         color: #999;
         font-style: italic;
      }
   </style>
</head>
<body>

<div class="container">
   <!-- Display Completed Orders -->
   <div class="order-container">
      <h2>Completed Orders</h2>
      <?php if(empty($completed_orders)): ?>
         <p class="empty-message">No completed orders</p>
      <?php else: ?>
         <?php foreach($completed_orders as $order): ?>
            <div class="order-item">
               <p>Name: <?php echo $order['name']; ?></p>
               <p>Price: Rs.<?php echo $order['price']; ?></p>
               <p>Image: <img src="uploaded_img/<?php echo $order['image']; ?>" alt="Product Image" style="max-width: 100px;"></p>
            </div>
         <?php endforeach; ?>
      <?php endif; ?>
   </div>
</div>

</body>
</html>
